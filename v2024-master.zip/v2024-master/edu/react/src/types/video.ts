export interface IVideo {
	id: number;
	lesson_id: number;
	chapter_id: number;
	title: string;
	order: number;
	view_num: number;
	created_at: string;
	updated_at: string;
}