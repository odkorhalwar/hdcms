<?php

namespace App\Http\Controllers;

use F9Web\ApiResponseHelpers;

abstract class Controller
{
    use ApiResponseHelpers;
}
