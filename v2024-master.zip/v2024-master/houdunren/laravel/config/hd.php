<?php
return [
    'code_timeout' => env('CODE_TIEMOUT', 20),
    'code_prefix' => env('CODE_PREFIX', 20)
];
