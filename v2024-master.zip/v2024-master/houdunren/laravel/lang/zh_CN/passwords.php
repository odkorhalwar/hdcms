<?php

declare(strict_types=1);

return [
    'reset'     => '密码重置成功！',
    'sent'      => '密码重置邮件已发送！',
    'throttled' => '请稍候再试。',
    'token'     => '密码重置令牌无效。',
    'user'      => '找不到该邮箱对应的用户。',
];
