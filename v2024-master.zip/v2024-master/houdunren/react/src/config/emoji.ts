export default [
	'ym', 'ch', 'fd', 'kx', 'ng', 'nu', 'shuai', 'wl', 'yl'
]