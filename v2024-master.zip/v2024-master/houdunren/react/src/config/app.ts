export default {
	//token
	token_name: 'token',
	lesson_page_row: 8,
	//视频分页条数
	video_page_row: 10,
	//贴子分页条数
	topic_page_row: 10,
}