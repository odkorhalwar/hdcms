window.api.menuEvent((value) => {
  document.querySelector('h1').innerHTML = value
})
