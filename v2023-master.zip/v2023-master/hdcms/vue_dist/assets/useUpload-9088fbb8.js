import{h as r}from"./index-e009af10.js";const a=()=>{function t(o,e="upload/image"){return r.request({url:e,method:"post",data:o})}return{uploadImage:t}};export{a as u};
