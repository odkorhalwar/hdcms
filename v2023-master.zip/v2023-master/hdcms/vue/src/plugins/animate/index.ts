import 'animate.css'

const setup = () => {}
export { setup }
